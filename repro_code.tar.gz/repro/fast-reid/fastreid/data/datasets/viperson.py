# encoding: utf-8
"""Minimal VIPerson loader for FastReID.

Filenames: {pid}_{n}.jpg
All images are used as the training set. No camera labels exist, so camid=0.
Query/gallery are empty; evaluate on Market-1501 (or another real test set).
"""

import glob
import os.path as osp
import re

from .bases import ImageDataset
from ..datasets import DATASET_REGISTRY


@DATASET_REGISTRY.register()
class VIPerson(ImageDataset):
    dataset_dir = "VIPerson"
    dataset_name = "viperson"

    def __init__(self, root="datasets", **kwargs):
        self.root = root
        self.data_dir = osp.join(self.root, self.dataset_dir)
        self.check_before_run([self.data_dir])

        train = lambda: self.process_dir(self.data_dir)
        query = []
        gallery = []
        super(VIPerson, self).__init__(train, query, gallery, **kwargs)

    def process_dir(self, dir_path):
        img_paths = glob.glob(osp.join(dir_path, "*.jpg"))
        pattern = re.compile(r"^(\d+)_(\d+)\.jpg$")

        data = []
        for img_path in img_paths:
            match = pattern.match(osp.basename(img_path))
            if match is None:
                continue
            pid = int(match.group(1))
            camid = 0
            data.append((
                img_path,
                self.dataset_name + "_" + str(pid),
                self.dataset_name + "_" + str(camid),
            ))
        return data
